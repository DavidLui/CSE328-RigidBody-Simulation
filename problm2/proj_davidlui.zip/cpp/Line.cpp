
#include "Line.h"

CLine::CLine()
{}

CLine::CLine(int pt1, int pt2)
{
	pts[0] = pt1;
	pts[1] = pt2;
}


CLine::~CLine()
{}